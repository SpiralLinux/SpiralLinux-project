bluetooth_policy.policy["media-role.use-headset-profile"] = false
